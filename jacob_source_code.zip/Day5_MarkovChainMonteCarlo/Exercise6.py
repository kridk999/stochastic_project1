import numpy as np
import scipy.stats as stats
import math
import matplotlib.pyplot as plt

# Parameters from Exercise 4
m = 10
lamb = 1
mean_service_time = 8
A = lamb * mean_service_time  # Traffic intensity (A = 8)

# 1. Unnormalized target distribution
def target_dist(i):
    if i < 0 or i > m:
        return 0.0
    return (A**i) / math.factorial(i)

# 2. Metropolis-Hastings Algorithm
num_iterations = 100000
burn_in = 5000  # Discard the first few thousand samples to allow the chain to converge
samples = []
current_state = 0  # Starting state

for _ in range(num_iterations):
    # Propose a new state: symmetric random walk (+1 or -1)
    proposal = current_state + np.random.choice([-1, 1])
    
    # Calculate acceptance ratio (alpha)
    # The proposal represents a symmetric transition q(i|j) = q(j|i), 
    # so they cancel out of the M-H ratio.
    if proposal < 0 or proposal > m:
        alpha = 0.0 # Out of bounds, definitely reject (target_dist = 0)
    else:
        alpha = min(1.0, target_dist(proposal) / target_dist(current_state))
    
    # Accept or reject
    if np.random.rand() < alpha:
        current_state = proposal
        
    samples.append(current_state)

# Discard burn-in phase and THIN the samples to remove autocorrelation
thinning_factor = 50 
valid_samples = samples[burn_in::thinning_factor]

# 3. Chi-squared goodness-of-fit test
print("--- Chi-Squared Goodness of Fit Test ---")

# Calculate observed frequencies
observed_counts = np.zeros(m + 1)
for s in valid_samples:
    observed_counts[s] += 1

# Calculate exact probabilities and expected counts
exact_probs = np.array([target_dist(i) for i in range(m + 1)])
exact_probs /= np.sum(exact_probs)  # Normalize it so they sum to 1

expected_counts = exact_probs * len(valid_samples)

# Perform the test
chi2_stat, p_value = stats.chisquare(f_obs=observed_counts, f_exp=expected_counts)

print(f"Chi-square Statistic: {chi2_stat:.4f}")
print(f"P-value: {p_value:.4f}")

# A p-value > 0.05 generally implies we fail to reject the null hypothesis,
# meaning our M-H samples fit the expected truncated Poisson distribution well.

# 4. Optional: Plot the comparison
plt.figure()
plt.bar(range(m + 1), observed_counts / len(valid_samples), alpha=0.6, label='M-H Simulated')
plt.plot(range(m + 1), exact_probs, 'ro-', label='Exact Analytical')
plt.title("Metropolis-Hastings vs Exact Distribution")
plt.xlabel("Number of busy lines")
plt.ylabel("Probability")
plt.legend()
plt.show()
