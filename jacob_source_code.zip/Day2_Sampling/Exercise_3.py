import numpy as np
import scipy.stats as stats
import matplotlib.pyplot as plt
import time
import seaborn as sns 

def plot_histogram(data, title, p=None, bins=None, pdf_func=None, pdf_args=()):
    sns.set_theme(style="whitegrid")
    
    # --- BIN LOGIC ---
    # If p is provided (discrete setup like Exercise 2) and bins isn't, center bins on integers
    if p is not None and bins is None:
        k = len(p)
        bins = np.arange(0.5, k + 1.5, 1)
    # If no bins provided at all, let matplotlib/numpy decide automatically (usually 'auto' or 'sturges')
    elif bins is None:
        bins = 'auto'

    # Plot empirical histogram
    plt.hist(data, bins=bins, density=True, alpha=0.7, color='steelblue', 
             edgecolor='black', label='Sampled Density')
    
    # --- OVERLAY LOGIC ---
    # Case 1: Discrete Probabilities (Exercise 2)
    if p is not None:
        k = len(p)
        x = np.arange(1, k + 1)
        plt.plot(x, p, marker='o', linestyle='--', color='crimson', 
                 linewidth=2, markersize=8, label='True Probabilities')
        plt.xticks(x)
        
    # Case 2: Continuous PDF (Exercise 3)
    elif pdf_func is not None:
        # Create a smooth x range based on the simulated data bounds
        xmin, xmax = plt.xlim()
        x = np.linspace(xmin, xmax, 1000)
        # Plot the theoretical continuous curve
        plt.plot(x, pdf_func(x, *pdf_args), 'r-', linewidth=2, label='Theoretical PDF')

    plt.title(title, fontsize=14, pad=10)
    plt.xlabel('Value', fontsize=12)
    plt.ylabel('Density / Probability', fontsize=12)
    plt.legend(frameon=True, shadow=True)
    plt.show()

def cos_sin_functions(n):
    cos_array = np.zeros(n)
    sin_array = np.zeros(n)
    
    # We must generate points until we have n accepted points
    count = 0
    while count < n:
        # Generate batch to test
        batch_size = n - count
        sign_cos, sign_sin = np.random.choice([-1, 1], (2, batch_size))
        V1, V2 = np.random.rand(2, batch_size)
        
        R = V1**2 + V2**2
        
        # Filter accepted ones (inside the unit circle)
        accepted = R < 1
        num_accepted = np.sum(accepted)
        
        if num_accepted > 0:
            # We don't take exactly V1/R, because R is squared distance. Note the sqrt.
            cos_array[count:count+num_accepted] = sign_cos[accepted] * V1[accepted] / np.sqrt(R[accepted])
            sin_array[count:count+num_accepted] = sign_sin[accepted] * V2[accepted] / np.sqrt(R[accepted])
            count += num_accepted
            
    return cos_array, sin_array

def box_muller_transform(n):
    n = n // 2  # We generate pairs, so we need n/2 pairs to get n samples
    # n is the number of PAIRS to generate
    U1 = np.random.rand(n)
    r = np.sqrt(-2 * np.log(U1))
    
    cos, sin = cos_sin_functions(n) 
    
    Z0 = r * cos
    Z1 = r * sin
    # Return as one univariate pool of 2n samples
    return np.concatenate((Z0, Z1))

def pareto_sampler(beta, k, n):
    U = np.random.rand(n)
    return beta * (U ** (-1/k))

def CI(data, confidence=0.95):
    mean = np.mean(data)
    sem = stats.sem(data)
    margin = sem * stats.t.ppf((1 + confidence) / 2., len(data)-1)
    return mean - margin, mean + margin

def plot_confidence_intervals(sampler_func, sampler_args, num_simulations, sample_size, true_mean, title):
    means = []
    ci_lowers = []
    ci_uppers = []
    hits_true_mean = []
    
    for _ in range(num_simulations):
        # Generate samples using the provided function and arguments
        sample_data = sampler_func(**sampler_args, n=sample_size)
        
        # Calculate mean and CI
        mean = np.mean(sample_data)
        ci_lower, ci_upper = CI(sample_data, confidence=0.95)
        
        means.append(mean)
        ci_lowers.append(ci_lower)
        ci_uppers.append(ci_upper)
        
        # Check if true mean is captured
        hits_true_mean.append(ci_lower <= true_mean <= ci_upper)
        
    # --- Plotting ---
    plt.figure(figsize=(10, 8))
    sns.set_theme(style="whitegrid")
    
    # Plot true mean line
    plt.axvline(x=true_mean, color='black', linestyle='--', linewidth=2, label=f'True Mean ({true_mean:.2f})')
    
    # Plot each interval
    for i in range(num_simulations):
        color = 'steelblue' if hits_true_mean[i] else 'crimson'
        plt.plot([ci_lowers[i], ci_uppers[i]], [i, i], color=color, linewidth=1.5)
        plt.plot(means[i], i, 'o', color=color, markersize=4)
        
    # Legend
    plt.plot([], [], color='steelblue', label='CI contains True Mean')
    plt.plot([], [], color='crimson', label='CI misses True Mean')
    
    pct_hit = sum(hits_true_mean) / num_simulations * 100
    
    plt.title(f'{title}\n'
              f'100 Simulated 95% CIs (n={sample_size}) | Coverage: {pct_hit:.1f}%', 
              fontsize=14, pad=10)
    plt.xlabel('Sample Value', fontsize=12)
    plt.ylabel('Simulation Run Index', fontsize=12)
    plt.legend(loc='upper right', frameon=True)
    plt.show()
    
def pareto_composition_sampler(beta, k, n):
    """
    Generate Pareto samples using the Composition method via Gamma-Exponential mixture.
    """
    # Step 1: Draw lambda from a Gamma distribution (shape=k, scale=1)
    # Note: np.random.gamma takes (shape, scale)
    lambdas = np.random.gamma(shape=k, scale=1.0, size=n)
    
    # Step 2: Draw Y from an Exponential distribution where the rate is lambda
    # Note: np.random.exponential takes the scale parameter, which is 1 / rate
    Y = np.random.exponential(scale=1.0 / lambdas, size=n)
    
    # Step 3: Transform Y to get the Pareto distributed X
    X = beta * np.exp(Y)
    
    return X

if __name__ == '__main__':
        # exponential distribution
        rv_exp = stats.expon()
        exp_samples = rv_exp.rvs(10000)
        #plot_histogram(exp_samples, title='Exponential Distribution Samples', pdf_func=stats.expon.pdf)
        
        # To plot the standard normal bell curve
        box_muller_samples = box_muller_transform(5000)
        #plot_histogram(box_muller_samples, title='Normal Distribution Samples', bins=50, pdf_func=stats.norm.pdf)
        
        # Pareto distribution
        beta = 1
        k_values = [2.05, 2.50, 3.0, 4.0]
        n_samples = 10000
        # colors = ['blue', 'green', 'orange', 'purple']
        pareto_samples = pareto_sampler(beta=beta, k=k_values[0], n=n_samples)
        
        # plt.figure(figsize=(10, 6))
        # sns.set_theme(style="whitegrid")
        
        # # Range for theoretical PDF
        # x = np.linspace(1, 10, 1000)
        
        # for i, k in enumerate(k_values):
        #     # 1. Generate samples
        #     pareto_samples = pareto_sampler(beta=beta, k=k, n=n_samples)
            
        #     # 2. Plot Histogram (restrict range of bins heavily to avoid outliers ruining the plot)
        #     plt.hist(pareto_samples, bins=np.linspace(1, 10, 50), density=True, 
        #              alpha=0.3, color=colors[i], label=f'Sampled (k={k})')
            
        #     # 3. Plot theoretical continuous curve
        #     pdf_y = stats.pareto.pdf(x, k, loc=0, scale=beta)
        #     plt.plot(x, pdf_y, color=colors[i], linestyle='-', linewidth=2, label=f'True PDF (k={k})')

        # plt.title('Comparison of Pareto Distributions for Different k values', fontsize=14, pad=10)
        # plt.xlabel('Value', fontsize=12)
        # plt.ylabel('Density', fontsize=12)
        # plt.xlim(1, 10)  # Restricting x-axis to zoom in on the important part
        # plt.ylim(0, 5.5) # Optional: Adjust y-axis to comfortably fit the peaks
        
        # # Place legend nicely
        # plt.legend(frameon=True, shadow=True, title="Distributions")
        # plt.show()
        
        # distribution test
        stat_box, _ = stats.kstest(box_muller_samples, 'norm')
        stat_pareto, _ = stats.kstest(pareto_samples, 'pareto', args=(k_values[0], 0, beta))
        stat_exp, _ = stats.kstest(exp_samples, 'expon')
        
        print(f"KS statistic for Box-Muller Normal: {stat_box:.4f}")
        print(f"KS statistic for Pareto (k={k_values[0]}): {stat_pareto:.4f}")
        print(f"KS statistic for Exponential: {stat_exp:.4f}")
        # all close to 0, indicating good fit to their respective distributions
        
        # Task 2
        #numerical values:
        num_mean = np.mean(pareto_samples)
        num_var = np.var(pareto_samples)
        
        # analytical values:
        analytical_mean = beta * k_values[0] / (k_values[0] -1)
        analytical_var = beta**2 * k_values[0] / ((k_values[0] - 1)**2 * (k_values[0] - 2))
        
        print(f"Numerical Mean: {num_mean:.4f}, Analytical Mean: {analytical_mean:.4f}")
        print(f"Numerical Variance: {num_var:.4f}, Analytical Variance: {analytical_var:.4f}")
        
        # Task 3: Visualize Confidence Intervals
    
        plot_confidence_intervals(
            sampler_func=box_muller_transform, 
            sampler_args={}, 
            num_simulations=100, 
            sample_size=10, 
            true_mean=0.0, 
            title="Confidence Intervals for Box-Muller (Normal)"
        )
        
        # The result show that about 5 out of 100 intervals do not contain the true mean, which is consistent with the expected 95% confidence level. The intervals that miss the true mean are highlighted in red, while those that capture it are in blue.
        
        # Task 4
                # Task 4: Simulate from the Pareto distribution using composition
        beta = 1
        k_comp = 2.5
        n_comp_samples = 10000
        
        # 1. Generate the samples using composition
        comp_samples = pareto_composition_sampler(beta=beta, k=k_comp, n=n_comp_samples)
        
        # 2. Visualize it using your plot function
        plot_histogram(comp_samples, title=f"Pareto Composition Sampler (k={k_comp})", 
                       bins=50, pdf_func=stats.pareto.pdf, pdf_args=(k_comp, 0, beta))
        
        # 3. Prove that it matches the theoretical distribution using Kolgomorov-Smirnov
        stat_comp, pval_comp = stats.kstest(comp_samples, 'pareto', args=(k_comp, 0, beta))
        print(f"\nKS statistic for Pareto Composition (k={k_comp}): {stat_comp:.4f} (p-value: {pval_comp:.4f})")



