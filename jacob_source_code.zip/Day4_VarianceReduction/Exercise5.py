import numpy as np
import scipy.stats as stats
import matplotlib.pyplot as plt
np.random.seed(42)

# Task 1 
def CI(data, confidence=0.95):
    mean = np.mean(data)
    sem = stats.sem(data)
    margin = sem * stats.t.ppf((1 + confidence) / 2., len(data)-1)
    return mean - margin,mean, mean + margin

# estimate the integral using crude MC
U = np.random.uniform(0, 1, 100)
MC_estimator = lambda U:  1 / 100 * np.sum(np.exp(U))
print("Crude MC point estimator:", MC_estimator(U))
CI_lower, sample_mean, CI_higher = CI([MC_estimator(uni) for uni in np.random.uniform(0,1,(100,100))])

print(f'The confidence interval for the crude MC estimate is {CI_lower}, {sample_mean}, {CI_higher}\n')
print(f'Interval width is {CI_higher - CI_lower}\n')
print(f'Analytical solution is {np.exp(1)-1}\n')

# Task 2
# estimate the integral using antithetic variates
f = lambda x: np.exp(x)
antithetic_estimator = lambda U: 1 / 100 * 1 / 2 * np.sum(f(U) + f(1-U))
CI_lower, sample_mean, CI_higher = CI([antithetic_estimator(uni) for uni in np.random.uniform(0,1,(100,100))])
print(f'The confidence interval for the antithetic variates estimate is {CI_lower}, {sample_mean}, {CI_higher}\n')
print(f'Interval width is {CI_higher - CI_lower}\n')

# Task 3
# estimate the integral using control variates
# estimate c
c_star = np.cov(f(U), U)[0, 1] / np.var(U)
CV = lambda U_random: f(U_random) - c_star * (U_random - 0.5)
print('control variate coefficient:', c_star)
CI_lower, sample_mean, CI_higher = CI([1 / 100 * np.sum(CV(uni)) for uni in np.random.uniform(0,1,(100,100))])
print(f'The confidence interval for the control variates estimate is {CI_lower}, {sample_mean}, {CI_higher}\n')
print(f'Interval width is {CI_higher - CI_lower}\n')

# Task 4
# estimate the integral using stratified sampling
def stratified_run(strata=10, samples_per_stratum=10):
    estimates = []
    for i in range(strata):
        U_strat = np.random.uniform(i/strata, (i+1)/strata, samples_per_stratum)
        estimates.append(np.mean(f(U_strat)))
    return np.mean(estimates) # The mean of all strata estimates is the total integral estimate

# To get a CI, run the whole stratified process multiple times:
CI_lower, sample_mean, CI_higher = CI([stratified_run() for _ in range(100)])
print(f'The confidence interval for the stratified sampling estimate is {CI_lower}, {sample_mean}, {CI_higher}\n')
print(f'Interval width is {CI_higher - CI_lower}\n')

# Task 5
# use control variates with stratified sampling to reduce variance further
def stratified_cv_run(strata=10, samples_per_stratum=10):
    estimates = []
    for i in range(strata):
        a = i / strata
        b = (i + 1) / strata
        U_strat = np.random.uniform(a, b, samples_per_stratum)
        
        if np.var(U_strat) > 0: 
            c_local = np.cov(f(U_strat), U_strat)[0, 1] / np.var(U_strat)
            
        expected_mean = (a + b) / 2
        
        cv_values = f(U_strat) - c_local * (U_strat - expected_mean)
        estimates.append(np.mean(cv_values))
        
    return np.mean(estimates)

CI_lower, sample_mean, CI_higher = CI([stratified_cv_run() for _ in range(100)])
print(f'The confidence interval for the stratified sampling with control variates estimate is {CI_lower}, {sample_mean}, {CI_higher}\n')
print(f'Interval width is {CI_higher - CI_lower}\n')

# Task 6
# Skipped because it wasnt covered this year

# Task 7
sigma = 2.5  # experiment with different variances
num_samples = 1000 # experiment with sample sizes

# Crude MC
Z = np.random.normal(0, 1, num_samples)
for a in [2, 4]:
    MC_estimate = np.mean(Z > a)
    print(f"Crude MC estimate of P(Z > {a}): {MC_estimate:.7f}")


f_pdf = lambda x: stats.norm.pdf(x, loc=0, scale=1)
g_pdf = lambda x, mean, sig: stats.norm.pdf(x, loc=mean, scale=sig)

for a in [2, 4]:
    X = np.random.normal(loc=a, scale=sigma, size=num_samples)
    weights = f_pdf(X) / g_pdf(X, a, sigma)

    IS_estimate = np.mean((X > a) * weights)
    print(f"Importance Sampling estimate of P(Z > {a}): {IS_estimate:.7f}")

print(f"Exact P(Z > 2): {1 - stats.norm.cdf(2):.7f}")
print(f"Exact P(Z > 4): {1 - stats.norm.cdf(4):.7f}")


# Task 8
h = lambda x: np.exp(x)
f_pdf = lambda x: np.where((x >= 0) & (x <= 1), 1.0, 0.0) # Uniform(0,1) PDF
g_pdf = lambda x, lamb: lamb * np.exp(-lamb * x)          # Exponential PDF

lambdas = np.linspace(0.5, 3.0, 100) # Test values for lambda
variances = []
num_samples = 1000

# 1. Step through different lambdas to find the minimum variance
for l in lambdas:
    X = np.random.exponential(scale=1/l, size=num_samples)
    evaluations = (h(X) * f_pdf(X)) / g_pdf(X, l)
    variances.append(np.var(evaluations))
    
optimal_lambda = lambdas[np.argmin(variances)]
min_variance = min(variances)
print(f"Empirically optimal lambda: {optimal_lambda:.2f} (Variance: {min_variance:.5f})")

# 2. Run the actual IS estimate using the best lambda
X_opt = np.random.exponential(scale=1/optimal_lambda, size=num_samples)
estimates_opt = (h(X_opt) * f_pdf(X_opt)) / g_pdf(X_opt, optimal_lambda)
final_IS_estimate = np.mean(estimates_opt)

print(f"Optimal IS integral estimate: {final_IS_estimate:.7f}")
print(f"Exact Analytical solution: {np.exp(1)-1:.7f}")


plt.figure()
plt.plot(lambdas, variances, label='Empirical Variance')
plt.axvline(optimal_lambda, color='red', linestyle='--', label=f'Optimal lambda approx {optimal_lambda:.2f}')
plt.title(r'Variance of IS Estimator vs. $\lambda$')
plt.xlabel(r'$\lambda$')
plt.ylabel('Variance')
plt.legend()
plt.show()


