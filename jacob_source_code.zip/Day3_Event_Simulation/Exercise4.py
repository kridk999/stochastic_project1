import numpy as np
import matplotlib.pyplot as plt
import scipy.stats as stats
import math

def simulate_queue(num_customers,inter_arrival, service_times, m=10, lamb=1, mu=8):
    inter_arrival = inter_arrival
    arrival_times = np.cumsum(inter_arrival)

    service_times = service_times

    blocked_customers = 0
    active_servers = []
    
    for i in range(num_customers):
        current_time = arrival_times[i] # current time is the arrival time of the current customer
        active_servers = [t_end for t_end in active_servers if t_end > current_time] # Remove servers that have completed service before the current time

        if len(active_servers) >= m: # if all ten available servers are in use, the current customer is blocked
            blocked_customers += 1
    
        else:
            departure_time = current_time + service_times[i] # If a server is free, add the service time to that server
            active_servers.append(departure_time)            # add departure time
    fraction_blocked = blocked_customers / num_customers     # calculate fraction of blocked customers

    return blocked_customers, fraction_blocked

# Confidence interval using sub sampling
def CI_sub_sampling(fractions, sim_runs, alpha=0.05):
    sample_mean = sum(fractions) / sim_runs
    sample_variance = 1 / (sim_runs - 1) * (sum([fractions[i] ** 2 for i in range(sim_runs)])-sim_runs * sample_mean ** 2)

    df = sim_runs-1
    t_stat = lambda alph: stats.t.ppf(alph, df)

    CI_lower, CI_higher = [sample_mean+np.sqrt(sample_variance) / np.sqrt(sim_runs) * t_stat(alpha/2),sample_mean+np.sqrt(sample_variance) / np.sqrt(sim_runs) * t_stat(1-alpha/2)]
    return CI_lower, sample_mean, CI_higher

# Run the simulation multiple times
total_blocked = 0
total_fraction = 0

sim_runs = 10
num_customers = 10000
m = 10 # number of servers
lamb = 1  # Average arrival rate (customers per unit time)
mu = 8  # Average service rate (customers per unit time)

fractions = []

for _ in range(sim_runs):
    #inter_arrival = np.random.poisson(lam=lamb, size=num_customers)
    inter_arrival = np.random.exponential(scale=1/lamb, size=num_customers)
    service_times = np.random.exponential(scale=mu, size=num_customers)
    blocked, fraction = simulate_queue(num_customers, inter_arrival, service_times, m, lamb, mu)
    fractions.append(fraction)

CI_lower, sample_mean, CI_higher = CI_sub_sampling(fractions, sim_runs)
print(f"confidence interval: [{CI_lower},{sample_mean}, {CI_higher}]")

# compare with exact solution
Erlang_B = ((lamb * mu)**m / math.factorial(m)) / sum([(lamb * mu)**i / math.factorial(i) for i in range(m+1)])
print("Erlang B formula result:", Erlang_B)

# Task 2
# Erlang distributed inter-arrival times
erlang_fractions = []
for _ in range(sim_runs):
    inter_arrival_erlang = np.random.gamma(shape=2, scale=0.5, size=num_customers)  # shape * scale = mean
    service_times_erlang = np.random.exponential(scale=mu, size=num_customers)
    blocked_erlang, fraction_erlang = simulate_queue(num_customers, inter_arrival_erlang, service_times_erlang, m, lamb, mu)
    erlang_fractions.append(fraction_erlang)
CI_lower_erlang, sample_mean_erlang, CI_higher_erlang = CI_sub_sampling(erlang_fractions, sim_runs)
print(f"Erlang inter-arrival times confidence interval: [{CI_lower_erlang},{sample_mean_erlang}, {CI_higher_erlang}]")

# Hyper-exponential distributed inter-arrival times
hyper_exponential_fractions = []
for _ in range(sim_runs):
    inter_arrival_hyper = np.random.exponential(scale=1/0.8333, size=num_customers) * 0.8 + np.random.exponential(scale=1/5.0, size=num_customers) * 0.2
    service_times_hyper = np.random.exponential(scale=mu, size=num_customers)
    blocked_hyper, fraction_hyper = simulate_queue(num_customers, inter_arrival_hyper, service_times_hyper, m, lamb, mu)
    hyper_exponential_fractions.append(fraction_hyper)
CI_lower_hyper, sample_mean_hyper, CI_higher_hyper = CI_sub_sampling(hyper_exponential_fractions, sim_runs)
print(f"Hyper-exponential inter-arrival times confidence interval: [{CI_lower_hyper},{sample_mean_hyper}, {CI_higher_hyper}]")

# Task 3
# constant service times
constant_service_fractions = []
for _ in range(sim_runs):
    inter_arrival_constant = np.random.exponential(scale=1/lamb, size=num_customers)
    service_times_constant = np.full(num_customers, mu)  # Constant service time
    blocked_constant, fraction_constant = simulate_queue(num_customers, inter_arrival_constant, service_times_constant, m, lamb, mu)
    constant_service_fractions.append(fraction_constant)
CI_lower_constant, sample_mean_constant, CI_higher_constant = CI_sub_sampling(constant_service_fractions, sim_runs)
print(f"Constant service times confidence interval: [{CI_lower_constant},{sample_mean_constant}, {CI_higher_constant}]")

# pareto service times
pareto_service_fractions_105 = []
k_1 = 1.05
xm_1 = mu * (k_1 - 1) / k_1  # Scale factor to make the mean equal to mu

for _ in range(sim_runs):
    inter_arrival_pareto = np.random.exponential(scale=1/lamb, size=num_customers)
    service_times_pareto = (np.random.pareto(a=k_1, size=num_customers) + 1) * xm_1
    blocked_pareto, fraction_pareto = simulate_queue(num_customers, inter_arrival_pareto, service_times_pareto, m, lamb, mu)
    pareto_service_fractions_105.append(fraction_pareto)

CI_lower_pareto_105, sample_mean_pareto_105, CI_higher_pareto_105 = CI_sub_sampling(pareto_service_fractions_105, sim_runs)
print(f"Pareto service times (k=1.05) confidence interval: [{CI_lower_pareto_105},{sample_mean_pareto_105}, {CI_higher_pareto_105}]")



pareto_service_fractions_205 = []
k_2 = 2.05
xm_2 = mu * (k_2 - 1) / k_2  # Scale factor to make the mean equal to mu
for _ in range(sim_runs):
    inter_arrival_pareto = np.random.exponential(scale=1/lamb, size=num_customers)
    service_times_pareto = (np.random.pareto(a=k_2, size=num_customers) + 1) * xm_2
    blocked_pareto, fraction_pareto = simulate_queue(num_customers, inter_arrival_pareto, service_times_pareto, m, lamb, mu)
    pareto_service_fractions_205.append(fraction_pareto)
CI_lower_pareto_205, sample_mean_pareto_205, CI_higher_pareto_205 = CI_sub_sampling(pareto_service_fractions_205, sim_runs)
print(f"Pareto service times (k=2.05) confidence interval: [{CI_lower_pareto_205},{sample_mean_pareto_205}, {CI_higher_pareto_205}]")

# choose a valid distribution for service times that have not already been used, and run the simulation again

# --- Plotting the Results ---

# Gather all the data you computed
labels = [
    "Poisson/Exp (Standard)",
    "Erlang/Exp", 
    "Hyper-Exp/Exp",
    "Poisson/Constant",
    "Poisson/Pareto (k=1.05)",
    "Poisson/Pareto (k=2.05)"
]

means = [
    sample_mean, 
    sample_mean_erlang,
    sample_mean_hyper,
    sample_mean_constant,
    sample_mean_pareto_105,
    sample_mean_pareto_205
]

ci_lowers = [
    CI_lower,
    CI_lower_erlang,
    CI_lower_hyper,
    CI_lower_constant,
    CI_lower_pareto_105,
    CI_lower_pareto_205
]

ci_uppers = [
    CI_higher,
    CI_higher_erlang,
    CI_higher_hyper,
    CI_higher_constant,
    CI_higher_pareto_105,
    CI_higher_pareto_205
]

# Matplotlib's 'yerr' expects the relative distance from the mean, not the absolute bounds
lower_errors = [m - l for m, l in zip(means, ci_lowers)]
upper_errors = [u - m for m, u in zip(means, ci_uppers)]
errors = [lower_errors, upper_errors]

# Create the plot
plt.figure(figsize=(10, 6))

# Plot confidence intervals
plt.errorbar(labels, means, yerr=errors, fmt='o', color='blue', capsize=5, capthick=1.5, label='Simulated 95% CIs')

# Plot the exact Erlang B solution as a horizontal line
plt.axhline(y=Erlang_B, color='red', linestyle='--', label=f'Exact Erlang B ({Erlang_B:.4f})')

# Formatting
plt.title('95% Confidence Intervals of Blocked Customers by Distribution', fontsize=14)
plt.ylabel('Fraction of Blocked Customers', fontsize=12)
plt.xticks(rotation=45, ha='right') # Rotate labels so they don't overlap
plt.grid(axis='y', linestyle='--', alpha=0.7)
plt.legend()
plt.tight_layout() # Ensures everything fits without clipping the labels
plt.show()

