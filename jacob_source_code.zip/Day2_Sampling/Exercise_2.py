import numpy as np
import matplotlib.pyplot as plt
import time
import seaborn as sns 

def plot_histogram(data, p, title):
    # Apply a clean seaborn theme
    sns.set_theme(style="whitegrid")
    
    k = len(p)
    bins = np.arange(0.5, k + 1.5, 1)
    
    # Plot empirical histogram with a nicer color
    plt.hist(data, bins=bins, density=True, alpha=0.7, color='steelblue', 
             edgecolor='black', label='Sampled Density')
    
    # Overlay original probabilities with a dashed line and distinct markers
    x = np.arange(1, k + 1)
    plt.plot(x, p, marker='o', linestyle='None', color='crimson', 
             linewidth=2, markersize=8, label='True Probabilities')
    
    plt.title(title, fontsize=14, pad=10)
    plt.xlabel('Value', fontsize=12)
    plt.ylabel('Density / Probability', fontsize=12)
    plt.xticks(x)
    plt.legend(frameon=True, shadow=True)
    plt.show()


def crude_sampler(p, n=10):
    cum_P = np.cumsum(p)
    rn = np.random.rand(n)
    X = {i+1:cum_P[i] for i in range(6)}
    xes = np.zeros(n, dtype=int)
    for j in range(n):
        for key, value in X.items():
            if rn[j] < value:
                xes[j] = key
                break
    return xes

def rejection_sampler(p, c, n=10):
    assert c < 1
    k = len(p)
    samples = np.zeros(n, dtype=int)
    for i in range(n):
        while True:
            U1 = np.random.rand()
            U2 = np.random.rand()
            I = np.floor(k*U1)+1
            if U2 <= p[int(I)-1]/c:
                samples[i] = int(I)
                break
    return samples

def alias_sampler(p, n=10):
    k = len(p)
    L = [i+1 for i in range(len(p))]
    F = [k*prob for prob in p]
 
    G = [i for i in range(k) if F[i]>=1.0]
    S = [i for i in range(k) if F[i]<1.0]
    z,y = 0,0
    
    # create the alias tables L and F
    while S and G:
        i = G.pop()
        j = S.pop()
        L[j]=i+1
        F[i]=F[i]-(1.0-F[j])
        if F[i]<0.99999:
            S.append(i)
        else: G.append(i)
    
    samples = np.zeros(n, dtype=int)
    for sample in range(n):
        U1 = np.random.rand()
        U2 = np.random.rand()
        I = np.floor(k*U1)+1
        if U2 < F[int(I)-1]:
            samples[sample] = int(I)
        else:
            samples[sample] = L[int(I)-1]
    return samples
        
if __name__ == "__main__":
    np.random.seed(42) 
    # p_values = [0.001, 0.1, 0.8]
    # n_samples = 10000

    # fig, axes = plt.subplots(1, 3, figsize=(18, 5))
    # sns.set_theme(style="whitegrid")

    # for i, p in enumerate(p_values):
    #     samples = np.random.geometric(p, size=n_samples)
        
    #     k_limit = int(np.percentile(samples, 99))
    #     x = np.arange(1, k_limit + 1)
        
    #     theoretical_p = (1 - p)**(x - 1) * p
        
    #     bins = np.arange(0.5, k_limit + 1.5, 1)
    #     axes[i].hist(samples, bins=bins, density=True, alpha=0.6, 
    #                  color='steelblue', edgecolor='black', label='Empirical')
    #     axes[i].step(x, theoretical_p, where='mid', color='crimson', 
    #                  linestyle='--', linewidth=2, label='Theoretical')
    #     axes[i].set_title(f'Geometric (p={p})')
    #     axes[i].set_xlabel('Value')
    #     axes[i].set_ylabel('Density')
    #     axes[i].legend()
    # plt.tight_layout()
    # plt.show()
    # Task 2
    p = [7/48, 5/48, 1/8, 1/16, 1/4, 5/16]
    print(p)
    n = 10000
    # a) Crude method
    t_crude = time.time()
    samples_crude = crude_sampler(p, n)
    t_crude = time.time() - t_crude
    print(f"Crude sampler took {t_crude:.4f} seconds")
    plot_histogram(samples_crude, p, 'Crude Sampler Results')
    
    # b) Rejection method
    t_rejection = time.time()
    c = np.max(p)+0.05
    samples_rejection = rejection_sampler(p, c, n)
    t_rejection = time.time() - t_rejection
    print(f"Rejection sampler took {t_rejection:.4f} seconds")
    plot_histogram(samples_rejection, p, 'Rejection Sampler Results')
    
    # c) Alias method
    t_alias = time.time()
    sample_alias = alias_sampler(p, n=n)
    t_alias = time.time() - t_alias
    print(f"Alias sampler took {t_alias:.4f} seconds")
    plot_histogram(sample_alias, p, 'Alias Sampler Results')
    
    # Benchmark Comparison
    print("\n" + "="*40)
    print(f"{'Method':<15} | {'Time (s)':<10} | {'Avg. Time/Sample (μs)':<15}")
    print("-" * 40)
    
    methods = [
        ("Crude", t_crude),
        ("Rejection", t_rejection),
        ("Alias", t_alias)
    ]
    
    for name, t in methods:
        avg_time = (t / n) * 1e6 # convert to microseconds
        print(f"{name:<15} | {t:<10.4f} | {avg_time:<15.4f}")
    print("="*40)