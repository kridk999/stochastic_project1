import numpy as np
import scipy.stats as stats
import matplotlib.pyplot as plt
np.random.seed(42)

# # EX 13 
# n = 10
# a = -5
# b = 5

# k = 1000

# Xi = [56,101,78,67,93,87,64,72,80,69]

# def CI(data, confidence=0.95):
#     mean = np.mean(data)
#     sem = stats.sem(data)
#     margin = sem * stats.t.ppf((1 + confidence) / 2., len(data)-1)
#     return mean - margin,mean, mean + margin

# def bootstrap_sample(Xi):
#     return np.random.choice(Xi, size=len(Xi), replace=True)

# def get_theta(sample):
#     thetas = []
#     for s in range(k):
#         sample = bootstrap_sample(Xi)
#         mu = np.mean(sample)
#         theta = sum(Xi) / n - mu
#         thetas.append(theta)
#     p_est = sum([1 if th < b and th > a else 0 for th in  thetas]) / k
#     return p_est

# p_estimate = get_theta(Xi)
# print(f"Bootstrap estimate of P(a < p < b): {p_estimate}")
# theta_samples = []
# for _ in range(k):
#     theta = get_theta(Xi)
#     theta_samples.append(theta)
# empirical_lower = np.percentile(theta_samples, 2.5)
# empirical_upper = np.percentile(theta_samples, 97.5)

# print(f"Empirical 95% Bootstrap CI: [{empirical_lower:.3f}, {empirical_upper:.3f}]")

# plt.figure(figsize=(8, 5))
# plt.hist(theta_samples, bins=50, color='lightblue', edgecolor='black', alpha=0.7)
# plt.axvline(empirical_lower, color='red', linestyle='--', linewidth=2, label=f'Lower CI ({empirical_lower:.3f})')
# plt.axvline(np.mean(theta_samples), color='green', linestyle='-', linewidth=2, label=f'Mean ({np.mean(theta_samples):.3f})')
# plt.axvline(empirical_upper, color='red', linestyle='--', linewidth=2, label=f'Upper CI ({empirical_upper:.3f})')
# plt.title('Bootstrap Estimates for P(a < p < b) with 95% CI')
# plt.xlabel('Estimated Probability')
# plt.ylabel('Frequency')
# plt.legend()
# plt.tight_layout()
# plt.show()

# # Task 15
# n = 15
# X = [5,4,9,6,21,17,11,20,7,10,21,15,13,16,8]

# def variance_est(X):
#     sample_variances = []
#     for _ in range(100):
#         sample = bootstrap_sample(X)
#         sample_mean = np.mean(sample)
#         S2 = sum([(x - sample_mean)**2 for x in sample]) / (n - 1)
#         sample_variances.append(S2)
#     var_S2 = np.var(sample_variances,ddof=1)
#     return var_S2
# print(f"Bootstrap estimate of Var(S^2): {variance_est(X)}")
# var_samples = []
# for _ in range(1000):
#     s2 = variance_est(X)
#     var_samples.append(s2)
# empirical_lower = np.percentile(var_samples, 2.5)
# empirical_upper = np.percentile(var_samples, 97.5)
# plt.figure(figsize=(8, 5))
# plt.hist(var_samples, bins=50, color='lightblue', edgecolor='black', alpha=0.7)
# plt.axvline(empirical_lower, color='red', linestyle='--', linewidth=2, label=f'Lower CI ({empirical_lower:.3f})')
# plt.axvline(np.mean(var_samples), color='green', linestyle='-', linewidth=2, label=f'Mean ({np.mean(var_samples):.3f})')
# plt.axvline(empirical_upper, color='red', linestyle='--', linewidth=2, label=f'Upper CI ({empirical_upper:.3f})')
# plt.title('Bootstrap Estimates for var(S2) with 95% CI')
# plt.xlabel('Estimated Probability')
# plt.ylabel('Frequency')
# plt.legend()
# plt.tight_layout()
# plt.show()



# Task 3
n = 200
Xi = np.random.pareto(a=1.05, size=n) + 1  

outer_k = 500  # Number of outer samples for CI precision
inner_k = 100  # Number of inner samples to estimate variance

def estimate_variances(data):
    inner_mu = []
    inner_med = []
    for _ in range(inner_k):
        sample = np.random.choice(data, size=len(data), replace=True)
        inner_mu.append(np.mean(sample))
        inner_med.append(np.median(sample))
    return np.var(inner_mu), np.var(inner_med)

# Double Bootstrap logic
var_mu_samples = []
var_med_samples = []

print(f"Starting double bootstrap ({outer_k} x {inner_k} iterations)...")
for i in range(outer_k):
    # Resample the original data (Outer Bootstrap)
    outer_sample = np.random.choice(Xi, size=n, replace=True)
    
    # Estimate variances for this specific resampling (Inner Bootstrap)
    v_mu, v_med = estimate_variances(outer_sample)
    
    var_mu_samples.append(v_mu)
    var_med_samples.append(v_med)
    
    if (i+1) % 50 == 0: print(f"Progress: {i+1}/{outer_k}")

# Calculate 95% Confidence Intervals
ci_var_mu = (np.percentile(var_mu_samples, 2.5), np.percentile(var_mu_samples, 97.5))
ci_var_med = (np.percentile(var_med_samples, 2.5), np.percentile(var_med_samples, 97.5))

print(f"\nResults for Pareto (a=1.05):")
print(f"Var(Mean):   Point Est: {np.mean(var_mu_samples):.4f} | 95% CI: [{ci_var_mu[0]:.4f}, {ci_var_mu[1]:.4f}]")
print(f"Var(Median): Point Est: {np.mean(var_med_samples):.4f} | 95% CI: [{ci_var_med[0]:.4f}, {ci_var_med[1]:.4f}]")

# Visualization
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))

ax1.hist(var_mu_samples, bins=30, color='salmon', edgecolor='black')
ax1.set_title("Precision of Var(Mean)")
ax1.axvline(ci_var_mu[0], color='blue', linestyle='--')
ax1.axvline(ci_var_mu[1], color='blue', linestyle='--')

ax2.hist(var_med_samples, bins=30, color='lightgreen', edgecolor='black')
ax2.set_title("Precision of Var(Median)")
ax2.axvline(ci_var_med[0], color='blue', linestyle='--')
ax2.axvline(ci_var_med[1], color='blue', linestyle='--')

plt.tight_layout()
plt.show()

