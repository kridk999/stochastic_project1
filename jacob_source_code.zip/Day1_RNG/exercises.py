import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import chisquare
import scipy.stats as stats

# task 1 alpha
def LCG(a,c,M, seq_length):
    x0 = seed
    sequence = []
    for _ in range(seq_length):
        x0 = (a * x0 + c) % M
        sequence.append(x0)
    return sequence

# Universal histogram plotter
def plot_histogram(data, bins):
    plt.hist(data, bins=bins, density=True, alpha=0.6, color='g')
    plt.title('Histogram of Generated Random Numbers')
    plt.xlabel('Value')
    plt.ylabel('Density')
    plt.grid()
    plt.show()

# Task 1 visualized
#plot_histogram(U, bins=10)


# Task 1 Bravo
def plot_scatter(data, title, percentage=0.05):
    # plot a scatter plot of the first x percent of the data.
    sample_size = int(len(data) * percentage)
    sample_data = data[:sample_size]
    plt.scatter(range(sample_size), sample_data, alpha=0.5)
    plt.title(title)
    plt.xlabel('Index')
    plt.ylabel('Value')
    plt.grid()
    plt.show()

# test for distribution type (chi-square test)
def chi_square_test(data, bins):
    observed, _ = np.histogram(data, bins=bins)
    expected = len(data) / bins
    chi2_stat = np.sum((observed - expected) ** 2 / expected)
    
    p_value = 1 - stats.chi2.cdf(chi2_stat, df=bins-1)
    return chi2_stat, p_value
  
def kolmogorov_smirnov_test(data):
    n = len(data)
    data_sorted = np.sort(data)
    cdf_theoretical = np.arange(1, n + 1) / n
    d_n = np.max(np.abs(data_sorted - cdf_theoretical))
    ks_mod = (np.sqrt(n) + 0.12 + 0.11 / np.sqrt(n)) * d_n
    
    p_value = 1 - stats.kstwobign.cdf(ks_mod)
    return ks_mod, p_value

def Wald_Wolfowitz_runs_test(data):     
    # calculate number of runs
    n = len(data)
    median = np.median(data)
    n1 = np.sum(data > median)
    n2 = np.sum(data <= median)
    transitions = 0
    for i in range(1, n):
        if (data[i] > median and data[i-1] <= median) or \
           (data[i] <= median and data[i-1] > median):
            transitions += 1
    R = transitions + 1
    
    # Evaluate result
    expected_R = (2 * n1 * n2) / (n1 + n2) + 1
    numerator = 2 * n1 * n2 * (2 * n1 * n2 - n1 - n2)
    denominator = ((n1 + n2)**2) * (n1 + n2 - 1)
    variance_R = numerator / denominator
    z_score = (R - expected_R) / np.sqrt(variance_R)
    p_value = 2 * (1 - stats.norm.cdf(abs(z_score)))
    return R, p_value, z_score

def Knuth_Up_Down(U, n):
    B = np.array([1/6, 5/24, 11/120,19/720,29/5040,1/840])
    A = np.array([[4529.4 ,9044.9 ,13568 ,18091 ,22615 ,27892],
                [9044.9 ,18097 ,27139 ,36187 ,45234 ,55789],
                [13568 ,27139 ,40721 ,54281 ,67852 ,83685],
                [18091 ,36187 ,54281 ,72414 ,90470 ,111580],
                [22615 ,45234 ,67852 ,90470 ,113262 ,139476],
                [27892 ,55789 ,83685 ,111580 ,139476 ,172860]],dtype=float)
    
    run_lengths = []
    current_run_length = 1
    for i in range(1, len(U)):
        if U[i] > U[i-1]:
            current_run_length += 1
        else:
            run_lengths.append(current_run_length)
            current_run_length = 1
            
    R = []
    for i in range(1, 6):
        R.append(run_lengths.count(i))
    R.append(sum(1 for x in run_lengths if x >= 6))
    R = np.array(R)
    
    Z = (1/(n-6)) * np.dot((R-n*B), np.dot(A, (R-n*B) ))
    p_value = 1-stats.chi2.cdf(Z, df=6-1)
    return Z, p_value

def run_testII_knuth(data):
    """Run test number two, this one is based on the number of runs of increasing numbers, and counts the number of runs of length 1, 2, 3, 4, 5 and 6 or more."""
    run_length = 1
    run_size = []
    for i in range(len(data)-1):
        if data[i] < data[i+1]:
            run_length = run_length + 1
        else:
            run_size.append(run_length)
            run_length = 1

    run_size.append(run_length)

    n = len(data)
    
    observed_runs = [x for x in run_size if x <= 6]
    R = np.array([observed_runs.count(r) for r in range(1,7)])
    B = np.array([1/6, 5/24, 11/120, 19/720, 29/5040, 1/840])
    A = np.array(
            [[4529.4, 9044.9, 13568, 18091, 22615, 27892],
             [9044.9, 18097, 27139, 36187, 45234, 55789], 
             [13568, 27139, 40721, 54281, 67852, 83685], 
             [18091, 36187, 54281, 72414, 90470, 111580], 
             [22615, 45234, 67852, 90470, 113262, 139476], 
             [27892, 55789, 83685, 111580, 139476, 172860]], dtype=float)
   
    Z = (1/(n-6)) * np.dot((R - n*B).T, np.dot(A, (R - n*B)))

    # evaluate against chi-2 distribution to find p-value
    p = 1-stats.chi2.cdf(Z, df=6-1)
    return Z, p

def evaluate_correlation(data, h):
    n = len(data)
    Ch = 1 / (n - h) * sum([data[i] * data[i+h] for i in range(n-h)])

    mu = 0.25
    sigma = np.sqrt(7 / (144 * n))
    
    z_score = (Ch - mu) / sigma
    p_value = 2 * (1 - stats.norm.cdf(abs(z_score)))
    
    return Ch, z_score, p_value

if __name__ == "__main__":
    # Generate the LCG sequence
    seed = 42 #42

    a,c = 1103515245, 12345 #3, 17
    mod = 133742067 #1327
    sequence_length = 10000
    
    # # Bad example
    a,c = 5, 1
    mod = 16
    
    x = LCG(a, c, mod, sequence_length)
    
    U = np.array(x) / mod

    # Plot histogram and scatter plot of the LCG output
    plot_histogram(U, bins=10)
    plot_scatter(U, 'Scatter Plot of the LCG output')

    # Perform chi-square test on LCG
    chi2_statistic, chi2_p_value = chi_square_test(U, bins=10)
    print(f"Chi-square statistic: {chi2_statistic}, p-value: {chi2_p_value}")

    # Perform Kolmogorov-Smirnov test on the LCG output
    ks_statistic, ks_p_value = kolmogorov_smirnov_test(U)
    print(f"Kolmogorov-Smirnov statistic: {ks_statistic}, p-value: {ks_p_value}")
    
    # Run the Wald-Wolfowitz runs test
    runs, p_val, z = Wald_Wolfowitz_runs_test(U)
    print(f"Wald-Wolfowitz: Runs={runs}, Z={z:.2f}, p-value={p_val:.4f}")
    
    Z, p = Knuth_Up_Down(U, 10000)
    print(f"Knuth Up-Down test statistic: {Z}, p-value: {p}")
    
    Z, p = run_testII_knuth(U)
    print(f"Run test II statistic: {Z}, p-value: {p}")

    for h in range(1, 11):
        Ch, z, p = evaluate_correlation(U, h)
        status = "REJECT" if p < 0.05 else "ACCEPT"
        print(f"Lag {h}: Ch={Ch:.4f}, Z={z:.2f}, p-value={p:.4f} ({status} H0)")
        
        
    # task C
    # A bad generator was 3, 17, 1337 i belive as it catched a pattern.
    # wasnt that one
    
    # Task 2
    np.random.seed(42)
    U = np.random.rand(10000)
    
    # Plot histogram and scatter plot of the LCG output
    plot_histogram(U, bins=10)
    plot_scatter(U, 'Scatter Plot of the LCG output')

    # Perform chi-square test on LCG
    chi2_statistic, chi2_p_value = chi_square_test(U, bins=10)
    print(f"Chi-square statistic: {chi2_statistic}, p-value: {chi2_p_value}")

    # Perform Kolmogorov-Smirnov test on the LCG output
    ks_statistic, ks_p_value = kolmogorov_smirnov_test(U)
    print(f"Kolmogorov-Smirnov statistic: {ks_statistic}, p-value: {ks_p_value}")
    
    # Run the Wald-Wolfowitz runs test
    runs, p_val, z = Wald_Wolfowitz_runs_test(U)
    print(f"Wald-Wolfowitz: Runs={runs}, Z={z:.2f}, p-value={p_val:.4f}")
    
    Z, p = Knuth_Up_Down(U, 10000)
    print(f"Knuth Up-Down test statistic: {Z}, p-value: {p}")
    
    Z, p = run_testII_knuth(U)
    print(f"Run test II statistic: {Z}, p-value: {p}")

    for h in range(1, 11):
        Ch, z, p = evaluate_correlation(U, h)
        status = "REJECT" if p < 0.05 else "ACCEPT"
        print(f"Lag {h}: Ch={Ch:.4f}, Z={z:.2f}, p-value={p:.4f} ({status} H0)")

